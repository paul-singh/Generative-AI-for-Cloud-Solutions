"""
common module.

This module contains necessary python files for both experimentation
and evaluation of Prompt Flow 'flows'
"""
